var emailRE = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
var currentStack;
var myDevices;


const customToolbar = {
  template: '#custom-toolbar',
  props: ['backLabel']
};

const mainPage = {
  template: '#mainPage',
  props: ['pageStack'],
  data(){
    
  }
};

const controlPage = {
  template: '#controlPage',
  props: ['pageStack'],
  components: { customToolbar }
};

const loginPage = {
  template: '#loginPage',
  computed: {
    validation: function () {
      
    },
    isValid: function () {
      
    }
  },
  methods: {
    login() {
      
    }
  },
  props: ['pageStack'],
  data() {
    return {
      user: { email: '', password: '' }
    };
  },
};

new Vue({
  el: '#app',
  template: '#main',
  data() {
    return {
      pageStack: [loginPage]
    };
  }
});